using UnityEngine;

public class FoodPickup : MonoBehaviour
{
    public float foodValue = 20f;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            other.GetComponent<PlayerStats>().EatFood(foodValue);
            Destroy(gameObject);
        }
    }
}