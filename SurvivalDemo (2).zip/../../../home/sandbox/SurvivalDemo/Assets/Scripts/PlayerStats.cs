using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour
{
    public float health = 100f;
    public float hunger = 100f;
    public float hungerDecreaseRate = 5f;

    public Slider healthBar;
    public Slider hungerBar;

    void Update()
    {
        hunger -= hungerDecreaseRate * Time.deltaTime / 60f;
        hunger = Mathf.Clamp(hunger, 0, 100);
        hungerBar.value = hunger;

        if (hunger <= 0)
        {
            health -= 10f * Time.deltaTime;
        }

        health = Mathf.Clamp(health, 0, 100);
        healthBar.value = health;

        if (health <= 0)
        {
            Debug.Log("You Died!");
        }
    }

    public void EatFood(float foodValue)
    {
        hunger += foodValue;
        hunger = Mathf.Clamp(hunger, 0, 100);
    }
}